# peluches > 2025-10-31 9:41pm
https://universe.roboflow.com/object-detection-3ljtf/peluches-hnorw

Provided by a Roboflow user
License: CC BY 4.0

