# peluches > 2025-11-01 9:16am
https://universe.roboflow.com/object-detection-3ljtf/peluches-hnorw

Provided by a Roboflow user
License: CC BY 4.0

